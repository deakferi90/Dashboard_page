import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { DashboardPage } from './pages/DashboardPage';
import { DetailsPage } from './pages/DetailsPage';
import { LoginPage } from './pages/LoginPage';
import { UsersPage } from './pages/UsersPage';
import { Products } from './pages/Products';
import { DashBoardTemplate } from './templates/DashboardTemplate/DashboardTemplate';
import { UserContext } from './context/UserContext';

function App() {
  const [users, setUsers] = useState([]);
  return (
    <UserContext.Provider value={{
      users, setUsers
    }}>
    <div>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<LoginPage />} />
          <Route path='/dashboard' element={<DashBoardTemplate><DashboardPage /></DashBoardTemplate>} />
          <Route path='/users' element={<DashBoardTemplate><UsersPage /></DashBoardTemplate>} />
          <Route path='/users/:id' element={<DashBoardTemplate><DetailsPage /></DashBoardTemplate>} />
          <Route path='/store' element={<DashBoardTemplate><Products /></DashBoardTemplate>} />
        </Routes>
      </BrowserRouter>
    </div>
    </UserContext.Provider>
  );
}

export default App;
