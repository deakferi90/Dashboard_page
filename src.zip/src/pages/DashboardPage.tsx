import React from "react";
import { Card } from "react-bootstrap";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { Doughnut } from "react-chartjs-2";
import data from "../mockData/chartData";
import card from "../mockData/cardData";

ChartJS.register(ArcElement, Tooltip, Legend);

export const DashboardPage = () => {
  return (
    <div className="wrapper">
      <div className="chart-container">
          <Doughnut data={data} options={{ maintainAspectRatio: false }} />
      </div>
      <div className="cards-container">
        {card.map((c) => (
          <Card key={c.title}>
            <Card.Body>
              <Card.Header style={{ backgroundColor: c.background }}>
                <Card.Title>{c.title}</Card.Title>
              </Card.Header>
              <Card.Text>{c.text}</Card.Text>
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
};
