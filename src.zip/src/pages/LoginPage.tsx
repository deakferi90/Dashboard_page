import { useNavigate } from "react-router-dom";
import { Button } from "antd";
import "./style.css";

export const LoginPage = () => {
  const navigate = useNavigate();
  const path = `dashboard`;

  const navigateToDashBoard = () => {
    navigate(path);
  };

  return (
    <div className="login-page-text">
      <div>
        MWTAdmin
      </div>
      <Button type="primary" onClick={navigateToDashBoard}>
        Login
      </Button>
    </div>
  );
};
