import { useEffect, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { UserContext } from "../context/UserContext";

export const UsersPage = () => {
  const [page, setPage] = useState(1);
  const [input, setInput] = useState('');
  const { users, setUsers } = useContext<any>(UserContext);
  let navigate = useNavigate();

  const routeChange = (id: string) => {
    let path = `${id}`;
    navigate(path);
  };

  const showDataInTable = async (current = page) => {
    const res = await axios.get(
      `https://randomuser.me/api?seed=905892cc10df9e43&results=7&page=${current}`
    );
    console.log(res.data.results);
    return res.data.results;
  };

  const filterList = (e: any) => {
      return setInput(e.target.value);
  };

  const setNextPage = () => {
    setPage(page + 1);
  };

  const setPrevPage = () => {
    setPage(page - 1);
  };

  useEffect(() => {
    showDataInTable().then((res) => {
      setUsers(res);
    });
  }, [page]);
  return (
    <div>
      <div>
        <input onChange={filterList} />
      </div>
      <div className="parent">
        {users.filter((user: { name: { last: any; first: any;} }) => (user.name.last.toLowerCase().includes(input) || user.name.first.toLowerCase().includes(input))).map((user: any) => (
          <div key={user.login.uuid} className="content-container">
            <div className="left-float">
              {user.name.first} {user.name.last}
            </div>
            <div className="right-float">
              <button
                onClick={() => routeChange(user.login.uuid)}
                className="btn btn-details"
              >
                Details
              </button>
            </div>
          </div>
        ))}
        <div className="button-container">
          <button className="btn btn-prev" onClick={setPrevPage}>
            Previous Page
          </button>
          <button className="btn btn-next" onClick={setNextPage}>
            Next Page
          </button>
        </div>
      </div>
    </div>
  );
};
