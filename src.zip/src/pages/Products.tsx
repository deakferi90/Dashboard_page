import { useEffect, useState } from "react";
import axios from "axios";

export const Products = () => {
  const [users, setUsers] = useState([]);

  const getProducts = async () => {
    const resp = await axios.get("https://fakestoreapi.com/products");
    return resp.data;
  };
  useEffect(() => {
    getProducts().then((resp) => {
      setUsers(resp);
    });
  }, []);
  return (
    <div className="products-container">
      {users.map((user: any) => (
        <div key={user.id} className="users-box">
        <div><img alt="" src={user.image}/></div>
        <div className="title">{user.title}</div>
        <div>Description: {user.description}</div>
        <div className="price">Price: {user.price}$</div>
        </div>
      ))}
    </div>
  );
};
