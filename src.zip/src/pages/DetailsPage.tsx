import { useContext } from "react";
import { useParams } from "react-router-dom";
import { UserContext } from "../context/UserContext";

export const DetailsPage = () => {
  const { id } = useParams();
  const { users } = useContext<any>(UserContext);
  const foundUser = users.find((user: { login: { uuid: string | undefined; }; }) => user.login.uuid === id);
  return (
    <div className="details-parent-container">
      <div className="upper-section">
        <img  alt="" src={foundUser.picture.large || foundUser.picture.medium} />
        <div className="names">{foundUser.name.last}</div>
        <div className="names">{foundUser.name.first}</div>
      </div>
      <div className="down-section">
        <div className="grid-item"><div className="name-tags">Name:</div><span>{foundUser.name.last} {foundUser.name.first}</span></div>
        <div className="grid-item"><div className="name-tags">E-mail:</div><span>{foundUser.email}</span></div>
        <div className="grid-item"><div className="name-tags">Phone number:</div><span>{foundUser.phone}</span></div>
        <div className="grid-item"><div className="name-tags">Location:</div><span>{foundUser.location.city}</span></div>
      </div>
    </div>
  );
};
