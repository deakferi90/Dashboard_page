export const card = [
    {
        id: 1,
        title: 'Card One',
        text: 'Card with following text',
        background: "rgba(255, 99, 132, 0.2)"
    },
    {
        id: 2,
        title: 'Card Two',
        text: 'Feri si creating the cards.',
        background: "rgba(54, 162, 235, 0.2)"
    },
    {
        id: 3,
        title: 'Card Three',
        text: 'Feri si creating the cards.',
        background: "rgba(255, 206, 86, 0.2)"
    },
    {
        id: 4,
        title: 'Card Four',
        text: 'Feri si creating the cards.',
        background: "rgba(75, 192, 192, 0.2)"
    },
    {
        id: 5,
        title: 'Card Five',
        text: 'Feri si creating the cards.',
        background: "rgba(153, 102, 255, 0.2)"
    },
    {
        id: 6,
        title: 'Card Six',
        text: 'Feri si creating the cards.',
        background: "rgba(255, 159, 64, 0.2)"
    },
];

export default card;