type User = {id: number, title: string, name: string, email: string, password: string, age: number }
export class Users {
    private users: User[] = [{
    id: 1,
    title: 'Person1',
    name: 'Feri',
    email: 'deak_fe@gmail.com',
    password: '1234',
    age: 32
},
{
    id: 2,
    title: 'Person2',
    name: 'Alex',
    email: 'alex@gmail.com',
    password: '1234',
    age: 36
},
{
    id: 3,
    title: 'Person3',
    name: 'Alex Bazatu',
    email: 'alex2@gmail.com',
    password: '1234',
    age: 30
}
];

    public addUser(user: User) {
        this.users.push(user);
        return new Promise((resolve, reject) => {
            resolve({
                status: 200,
                user
            })
        })
    }

    public getUsers() {
        return new Promise((resolve, reject) => {
            resolve({
                status: 200,
                users: this.users
            })
        })
    }
}
