import * as React from "react";
import { NavLink } from "react-router-dom";
import "./style.css";

const SideBar = () => {
  let activeClassName = "active";
  return (
    <div className="side-bar">
      <div className="side-bar-title">Mint<span>Web</span>Tuts</div>
      <div className="text-wrapper">
        <NavLink
          to={"/dashboard"}
          className={({ isActive }) => (isActive ? activeClassName : "text")}
        >
          Dashboard
        </NavLink>
      </div>
      <div className="text-wrapper">
        <NavLink
          to={"/users"}
          className={({ isActive }) => (isActive ? activeClassName : "text")}
        >
          Users
        </NavLink>
      </div>
      <div className="text-wrapper">
        <NavLink
          to={"/store"}
          className={({ isActive }) => (isActive ? activeClassName : "text")}
        >
          Store
        </NavLink>
      </div>
    </div>
  );
};

export default SideBar;
