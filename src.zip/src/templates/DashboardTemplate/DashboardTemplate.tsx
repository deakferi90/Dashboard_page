import SideBar from '../../SideBar/SideBar';
import './style.css';

export const DashBoardTemplate = ({children}: any) => {
    return <div className='dashboard-template'>
        <div className='sidebar'>
            <SideBar/>
        </div>
        <div className='content'>{children}</div>
    </div>
}